package com.localbasket.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;
import com.localbasket.dao.OneSignalDao;
import com.localbasket.model.OneSignalModel;
import com.localbasket.service.impl.DefaultOneSignalService;
import static org.mockito.BDDMockito.given;
import org.junit.Assert;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RunWith(SpringRunner.class)
public class DefaultOneSignalServiceTest {

	@MockBean
	private OneSignalDao oneSignalDao;
	
	@Autowired
	private OneSignalService oneSignalService;
	
	@TestConfiguration
	static class OneSignalServiceTestContextConfiguration{
		@Bean
		public OneSignalService getOneSignalService() {
			return new DefaultOneSignalService();
		}
	}
	@Test
	public void getOneSignalTest(){
		OneSignalModel oneSignalModel= new OneSignalModel();
		oneSignalModel.setId((long) 123);
		oneSignalModel.setToken("sample");
		given(oneSignalDao.findById((long) 123)).willReturn(Optional.of(oneSignalModel));
		OneSignalModel oneSignal=oneSignalService.getOneSignal(Long.valueOf(123));
		Assert.assertEquals(oneSignal.getToken(), "sample");
	}
	
	@Test
	public void createOneSignalTest() {
		OneSignalModel oneSignalModel= new OneSignalModel();
		oneSignalModel.setId((long) 123);
		oneSignalModel.setToken("sample");
		given(oneSignalDao.save(oneSignalModel)).willReturn(oneSignalModel);
		OneSignalModel oneSignal=oneSignalService.createOneSignal(oneSignalModel);
		Assert.assertEquals(oneSignal.getToken(), "sample");
	}
	
	@Test
	public void findAllTest() {
		List<OneSignalModel> list= new ArrayList<>();
		OneSignalModel oneSignalModel= new OneSignalModel();
		oneSignalModel.setId((long) 123);
		oneSignalModel.setToken("sample");
		list.add(oneSignalModel);
		
		given(oneSignalDao.findAll()).willReturn(list);
		List<OneSignalModel> oneSignal=oneSignalService.findAll();
		Assert.assertEquals(oneSignal.get(0).getToken(), "sample");
	}
}
