package com.localbasket.application;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = {"com.localbasket"})
@EnableJpaRepositories("com.localbasket.dao")
@EntityScan("com.localbasket.model")
public class Application {

	private static final Logger logger = LoggerFactory.getLogger(Application.class);
    public static void main(String[] args) {
    	logger.info("Local Basket");
        SpringApplication.run(Application.class, args);
    }
}
