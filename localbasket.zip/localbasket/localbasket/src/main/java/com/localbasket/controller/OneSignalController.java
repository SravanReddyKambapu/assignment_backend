package com.localbasket.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.localbasket.application.Application;
import com.localbasket.model.OneSignalModel;
import com.localbasket.service.OneSignalService;

@RestController
@RequestMapping("/onesignal")
public class OneSignalController {
	
	private static final Logger logger = LoggerFactory.getLogger(OneSignalController.class);
	
	@Autowired
	private OneSignalService oneSignalService;
	
	@PostMapping("/create")
	public OneSignalModel createOneSignal(@RequestBody OneSignalModel oneSignalModel) {
		
		logger.info("Creating item with details: "+oneSignalModel);
		return oneSignalService.createOneSignal(oneSignalModel);
	}
	
	@GetMapping("/find")
	public OneSignalModel getOneSignal(Long id) {
		logger.info("Finding item with id: "+id);
		return oneSignalService.getOneSignal(id);
	}
	
	@GetMapping("/all")
	public List<OneSignalModel> findAll() {
		logger.info("Finding all items ");
		return oneSignalService.findAll();
	}
	
	@DeleteMapping("/delete")
	public List<OneSignalModel> delete(Long id) {
		logger.info("Deleting item with id "+id);
		oneSignalService.delete(id);
		return oneSignalService.findAll();
	}
}
