package com.localbasket.service.impl;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.localbasket.controller.OneSignalController;
import com.localbasket.dao.OneSignalDao;
import com.localbasket.model.OneSignalModel;
import com.localbasket.service.OneSignalService;

@Service
public class DefaultOneSignalService implements OneSignalService{
	private static final Logger logger = LoggerFactory.getLogger(OneSignalController.class);
	@Autowired
	private OneSignalDao oneSignalDao;
	@Override
	public OneSignalModel createOneSignal(OneSignalModel oneSignal) {
		return oneSignalDao.save(oneSignal);
	}

	@Override
	public OneSignalModel getOneSignal(Long id) {
		Optional<OneSignalModel> oneSignal=oneSignalDao.findById(id);
		if(oneSignal.isPresent()) {
			return oneSignal.get();
		}
		logger.info("No item found with id: "+id);
		return null;
	}

	@Override
	public List<OneSignalModel> findAll() {
		return oneSignalDao.findAll();
	}
	@Override
	public void delete(Long id) {
		OneSignalModel oneSignalModel=getOneSignal(id);
		logger.info("Deleted Item "+oneSignalModel);
		oneSignalDao.delete(oneSignalModel);
	}

}
