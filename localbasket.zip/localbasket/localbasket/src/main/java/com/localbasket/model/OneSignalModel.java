package com.localbasket.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ONE_SIGNAL")
public class OneSignalModel {
	
	@Id
	@GeneratedValue
	private Long id;
	
	@Column(name="TOKEN")
	private String token;
	
	private Long customer;
	private Long store;
	public Long getCustomer() {
		return customer;
	}
	public void setCustomer(Long customer) {
		this.customer = customer;
	}
	public Long getStore() {
		return store;
	}
	public void setStore(Long store) {
		this.store = store;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	@Override
	public String toString() {
		return "OneSignalModel [id=" + id + ", token=" + token + ", customer=" + customer + ", store=" + store + "]";
	}
	
		
}
